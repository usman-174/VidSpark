-- AlterTable
ALTER TABLE "User" ADD COLUMN     "resetToken" TEXT;

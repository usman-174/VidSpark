-- AlterTable
ALTER TABLE "Invitation" ALTER COLUMN "inviteLink" DROP NOT NULL;

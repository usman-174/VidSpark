-- DropIndex
DROP INDEX "Video_countryCode_trendingDate_idx";

-- DropIndex
DROP INDEX "Video_videoId_idx";
